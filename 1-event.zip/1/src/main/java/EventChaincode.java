
/****************************************************** 
 *  Copyright 2018 IBM Corporation 
 *  Licensed under the Apache License, Version 2.0 (the "License"); 
 *  you may not use this file except in compliance with the License. 
 *  You may obtain a copy of the License at 
 *  http://www.apache.org/licenses/LICENSE-2.0 
 *  Unless required by applicable law or agreed to in writing, software 
 *  distributed under the License is distributed on an "AS IS" BASIS, 
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 *  See the License for the specific language governing permissions and 
 *  limitations under the License.
 */

import java.util.Vector;
import java.util.regex.Pattern;

import org.example.client.CAClient;
import org.example.client.ChannelClient;
import org.example.client.FabricClient;
import org.example.config.Config;
import org.example.user.UserContext;
import org.example.util.Util;
import org.hyperledger.fabric.sdk.BlockEvent;
import org.hyperledger.fabric.sdk.ChaincodeEvent;
import org.hyperledger.fabric.sdk.ChaincodeEventListener;
import org.hyperledger.fabric.sdk.Channel;
import org.hyperledger.fabric.sdk.Orderer;
import org.hyperledger.fabric.sdk.Peer;
import org.hyperledger.fabric.sdk.exception.InvalidArgumentException;

import com.google.protobuf.InvalidProtocolBufferException;

/**
 * 
 * @author Balaji Kadambi
 *
 */

class ChaincodeEventCapture { // A test class to capture chaincode events
	final String handle;
	final BlockEvent blockEvent;
	final ChaincodeEvent chaincodeEvent;

	ChaincodeEventCapture(String handle, BlockEvent blockEvent, ChaincodeEvent chaincodeEvent) {
		this.handle = handle;
		this.blockEvent = blockEvent;
		this.chaincodeEvent = chaincodeEvent;
	}

	/**
	 * @return the handle
	 */
	public String getHandle() {
		return handle;
	}

	/**
	 * @return the blockEvent
	 */
	public BlockEvent getBlockEvent() {
		return blockEvent;
	}

	/**
	 * @return the chaincodeEvent
	 */
	public ChaincodeEvent getChaincodeEvent() {
		return chaincodeEvent;
	}

}

//crypto-config/peerOrganizations/org1.example.com/users/Admin@org1.example.com/msp/keystore

public class EventChaincode {

	public static void main(String args[]) {
		try {
			Util.cleanUp();
			String caUrl = Config.CA_ORG1_URL;
			CAClient caClient = new CAClient(caUrl, null);
			// Enroll Admin to Org1MSP
			UserContext adminUserContext = new UserContext();
			adminUserContext.setName(Config.ADMIN);
			adminUserContext.setAffiliation(Config.ORG1);
			adminUserContext.setMspId(Config.ORG1_MSP);
			caClient.setAdminUserContext(adminUserContext);
			adminUserContext = caClient.enrollAdminUser(Config.ADMIN, Config.ADMIN_PASSWORD);

			FabricClient fabClient = new FabricClient(adminUserContext);

			ChannelClient channelClient = fabClient.createChannelClient(Config.CHANNEL_NAME);
			Channel channel = channelClient.getChannel();
			Peer peer = fabClient.getInstance().newPeer(Config.ORG1_PEER_0, Config.ORG1_PEER_0_URL);
			// EventHub eventHub = fabClient.getInstance().newEventHub("eventhub01",
			// "grpc://localhost:7053");
			Orderer orderer = fabClient.getInstance().newOrderer(Config.ORDERER_NAME, Config.ORDERER_URL);
			channel.addPeer(peer);
			// channel.addEventHub(eventHub);
			channel.addOrderer(orderer);
			channel.initialize();

			//

			Vector<ChaincodeEventCapture> chaincodeEvents = new Vector<ChaincodeEventCapture>();

			// START CHAINCODE EVENT LISTENER HANDLER----------------------
			String expectedEventName = "myevent";
			String chaincodeEventListenerHandle = EventChaincode.setChaincodeEventListener(channel, expectedEventName,
					chaincodeEvents);
			// END CHAINCODE EVENT LISTENER HANDLER------------------------

			// START WAIT FOR THE EVENT-------------------------------------
//		    while (chaincodeEvents.isEmpty()) {
//	            // do nothing
//	        }
//		    
			boolean eventDone = false;
			eventDone = EventChaincode.waitForChaincodeEvent(150, channel, chaincodeEvents,
					chaincodeEventListenerHandle);
			System.out.println("eventDone: " + eventDone);
////		    // END WAIT FOR THE EVENT---------------------------------------
//		    

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static String setChaincodeEventListener(Channel channel, String expectedEventName,
			final Vector<ChaincodeEventCapture> chaincodeEvents) throws InvalidArgumentException {
		System.out.println("setChaincodeEventListener ");
		ChaincodeEventListener chaincodeEventListener = new ChaincodeEventListener() {

			public void received(String handle, BlockEvent blockEvent, ChaincodeEvent chaincodeEvent) {
				chaincodeEvents.add(new ChaincodeEventCapture(handle, blockEvent, chaincodeEvent));

				// Here put what you want to do when receive chaincode event
				System.out.println("RECEIVED CHAINCODE EVENT with handle: " + handle + ", chaincodeId: "
						+ chaincodeEvent.getChaincodeId() + ", " + "chaincode event name: "
						+ chaincodeEvent.getEventName() + ", transactionId: " + chaincodeEvent.getTxId()
						+ ", event Payload: " + new String(chaincodeEvent.getPayload()));
			}
		};
		// chaincode events.
		String eventListenerHandle = channel.registerChaincodeEventListener(Pattern.compile(".*"),
				Pattern.compile(Pattern.quote(expectedEventName)), chaincodeEventListener);
		System.out.println("eventListenerHandle:" + eventListenerHandle);
		return eventListenerHandle;
	}

	public static boolean waitForChaincodeEvent(Integer timeout, Channel channel,
			Vector<ChaincodeEventCapture> chaincodeEvents, String chaincodeEventListenerHandle)
			throws InvalidArgumentException {
		boolean eventDone = false;
		if (chaincodeEventListenerHandle != null) {

			int numberEventsExpected = 50; // channel.getEventHubs().size() +
											// channel.getPeers(EnumSet.of(Peer.PeerRole.EVENT_SOURCE)).size();
			System.out.println("numberEventsExpected: " + numberEventsExpected);
			// just make sure we get the notifications
			if (timeout.equals(0)) {
				// get event without timer
				while (chaincodeEvents.size() != numberEventsExpected) {
					// do nothing
				}
				eventDone = true;
			} else {
				// get event with timer
				for (int i = 0; i < timeout; i++) {
					if (chaincodeEvents.size() == numberEventsExpected) {
						eventDone = true;
						break;
					} else {
						try {
							double j = i;
							j = j / 10;
							System.out.println(j + " second");
							Thread.sleep(100); // wait for the events for one tenth of second.
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
					}
				}
			}

			System.out.println("chaincodeEvents.size(): " + chaincodeEvents.size());

			// unregister event listener
			channel.unregisterChaincodeEventListener(chaincodeEventListenerHandle);
			int i = 1;
			// arrived event handling
			for (ChaincodeEventCapture chaincodeEventCapture : chaincodeEvents) {
				System.out.println("Event number. " + i);
				System.out.println("event capture object: " + chaincodeEventCapture.toString());
				System.out.println("Event Handle: " + chaincodeEventCapture.getHandle());
				System.out.println("Event TxId: " + chaincodeEventCapture.getChaincodeEvent().getTxId());
				System.out.println("Event Name: " + chaincodeEventCapture.getChaincodeEvent().getEventName());
				System.out.println("Event Payload: " + chaincodeEventCapture.getChaincodeEvent().getPayload()); // byte
				System.out.println("Event ChaincodeId: " + chaincodeEventCapture.getChaincodeEvent().getChaincodeId());
				BlockEvent blockEvent = chaincodeEventCapture.getBlockEvent();
				try {
					System.out.println("Event Channel: " + blockEvent.getChannelId());
				} catch (InvalidProtocolBufferException e) {
					e.printStackTrace();
				}

				i++;
			}

		} else {
			System.out.println("chaincodeEvents.isEmpty(): " + chaincodeEvents.isEmpty());
		}
		System.out.println("eventDone: " + eventDone);
		return eventDone;
	}

}